<footer class="nav mt-4 px-3 bg-primary rounded justify-content-center">
    <div class="nav-link text-white">
        &copy; SITI ZAHRA AZIZAH - XII PPLG A
    </div>
</footer>