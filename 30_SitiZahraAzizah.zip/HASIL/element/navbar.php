<?php
require_once "function.php";
// logout jika button di tekan akan memanggil function logout yg ada di function.php
if (isset($_POST["logout"])){
    logout();
}
?>

<nav class="navbar my-4 px-3 text-white bg-primary rounded">
    <ul class="nav nav-pills">
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="home.php">Beranda</a>
        </li>
        <li class="nav-item">
            <a class="nav-link disabled" href="#">Transaksi</a>
        </li>
    </ul>
    <ul class="nav justify-content-end">
        <li class="nav-item">
            <form method="post">
                <button class="btn btn-danger" type="submit" name="logout" id="logout">Logout</button>
            </form>
        </li>
    </ul>
</nav>