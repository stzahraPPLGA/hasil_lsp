<?php
require_once "function.php";
session_start();
// untuk mengautentikasi user tetap berada di halaman, dan jika logout maka user tidak dapat masuk ke halaman ini tanpa login
if (!$_SESSION["auth"]){
    header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Beranda</title>
</head>
<body class="container">
    
    <?php require_once "element/navbar.php"; ?>
    <!-- untuk memanggil halaman navbar -->

    <div class="text-center my-4">
        <img src="image/skendagallery.jpg" class="img-thumbnail" style="width: 1500px;">
    </div>

    <h2 class="my-4">Daftar Produk Technopark Gallery SMKN 2 BANJARMASIN</h2>

    <?php $i = 0; ?>
    <div class="row row-cols-4 g-4 d-flex justify-content-center">
        <!-- menampilkan produk dengan perulangan dan memanggil data array-->
        <?php foreach($dataproduk as $data): ?>
            <div class="col">
                <div class="card" style="height: 34rem;">
                    <img src="<?= $data[3]; ?>" alt="" class="card-img-top">
                    <div class="card-body">
                        <h4 class="card-title"><?= $data[0]; ?></h4>
                        <p class="card-text"><?=$data[1]; ?></p>
                        <p class="card-text">Rp. <?= $data[2]; ?></p>
                    </div>
                </div>
                
                <a href="action.php?id=<?= $i++;?>" class="btn btn-primary d-grid mx-auto my-4">PILIH PRODUK</a><br>

            </div>
        <?php endforeach;?>
    </div>
    
    <!-- untuk memanggi halaman footer -->
    <?php require_once "element/footer.php"; ?>
    <!-- link script untuk menghubungkan framework bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>