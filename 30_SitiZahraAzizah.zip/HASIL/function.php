<?php
// login function
function login() {
    // method post untuk menjalankan login
    if($_SERVER["REQUEST_METHOD"] == "POST") { 
        $username = $_POST["username"];
        $password = $_POST["password"];
        // jika username dan password sesuai maka user dapat login dengan autentikasi
        if ($username == "userlsp" && $password == "smkn2bjm") {
            $auth = $_SESSION["auth"] = "$username";
            setcookie("auth", $auth);
            header("Location: home.php");
            // setelah login akan terarah ke halaman beranda
            exit();
        } else {
            // jika username dan password salah maka akan muncul alert dan user tidak dapat masuk
            echo "<div class='mt-3 alert alert-danger text-center'>Username dan Password salah</div>";
        }
    }
}
// data produk dalam bentuk array multi dimensi
$dataproduk = array (
    array("PAKAN IKAN OTOMATIS", "Beri makan ikan tanpa repot dengan pakan ikat otomatis produk dari jurusan RPL", 100000, "image/pakanikan.png"), 
    array("WEBSITE COMPANY PROFILE", "Zaman now masih belum punya website percayakan pembuatan website pada kula koding SMKN 2 Banjarmasin", 45000, "image/website.png"),
    array("KURSI JATI", "Kursi estetik dengan bahan jati dibuat oleh jurusan Teknik Furniture", 50000, "image/kursi-jati.jpg"),
    array("SABUN LAUNDRY", "Mewangikan pakaian menggunakan bahan yang aman untuk pakaian produksi dari jurusan Kimia Industri", 55000, "image/sabunlaundry.png")
);

// logout function 
// fungsi ini dipanggil ke halaman button logout
function logout() {
    session_start();
    setcookie("auth", "", 100);
    session_unset();
    session_destroy();

    // jika button di tekan maka user akan keluar dari akun dan terarah ke halaman login
    header("Location: login.php");
    exit();
}
?>